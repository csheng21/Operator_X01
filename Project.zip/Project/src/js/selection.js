class ScreenshotSelector {
    constructor() {
        this.isSelecting = false;
        this.startX = 0;
        this.startY = 0;
        this.overlay = null;
        this.selection = null;
        this.info = null;
    }

    start() {
        // Create overlay
        this.overlay = document.createElement('div');
        this.overlay.className = 'screenshot-overlay';
        document.body.appendChild(this.overlay);

        // Create info display
        this.info = document.createElement('div');
        this.info.className = 'screenshot-info';
        document.body.appendChild(this.info);

        // Add event listeners
        this.overlay.addEventListener('mousedown', this.onMouseDown.bind(this));
        document.addEventListener('mousemove', this.onMouseMove.bind(this));
        document.addEventListener('mouseup', this.onMouseUp.bind(this));
        document.addEventListener('keydown', this.onKeyDown.bind(this));
    }

    onMouseDown(e) {
        this.isSelecting = true;
        this.startX = e.clientX;
        this.startY = e.clientY;

        // Create selection area
        this.selection = document.createElement('div');
        this.selection.className = 'screenshot-area';
        document.body.appendChild(this.selection);
    }

    onMouseMove(e) {
        if (!this.isSelecting) return;

        const currentX = e.clientX;
        const currentY = e.clientY;

        const left = Math.min(this.startX, currentX);
        const top = Math.min(this.startY, currentY);
        const width = Math.abs(currentX - this.startX);
        const height = Math.abs(currentY - this.startY);

        this.selection.style.left = `${left}px`;
        this.selection.style.top = `${top}px`;
        this.selection.style.width = `${width}px`;
        this.selection.style.height = `${height}px`;

        // Update info display
        this.info.textContent = `${width}px × ${height}px`;
        this.info.style.left = `${left}px`;
        this.info.style.top = `${top - 25}px`;
    }

    async onMouseUp(e) {
        if (!this.isSelecting) return;
        this.isSelecting = false;

        const width = Math.abs(e.clientX - this.startX);
        const height = Math.abs(e.clientY - this.startY);

        if (width < 10 || height < 10) {
            this.cleanup();
            return;
        }

        // Get the selected area coordinates
        const area = {
            x: Math.min(this.startX, e.clientX),
            y: Math.min(this.startY, e.clientY),
            width,
            height
        };

        // Send message to background script with coordinates
        chrome.runtime.sendMessage({
            action: 'captureArea',
            area: area
        });

        this.cleanup();
    }

    onKeyDown(e) {
        if (e.key === 'Escape') {
            this.cleanup();
        }
    }

    cleanup() {
        if (this.overlay) this.overlay.remove();
        if (this.selection) this.selection.remove();
        if (this.info) this.info.remove();
        document.removeEventListener('mousemove', this.onMouseMove);
        document.removeEventListener('mouseup', this.onMouseUp);
        document.removeEventListener('keydown', this.onKeyDown);
    }
}

// Listen for messages from the extension
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'startSelection') {
        new ScreenshotSelector().start();
    }
});