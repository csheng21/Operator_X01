document.getElementById('openSidePanel').addEventListener('click', () => {
    chrome.sidePanel.open();
    window.close();
});