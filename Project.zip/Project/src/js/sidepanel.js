import { api } from './api.js';
import { config } from './config.js';
import { uiUtils } from './uiUtils.js';
import { messageHandler } from './messageHandler.js';
import { fileHandler } from './fileHandler.js';
import { screenshotHandler } from './screenshotHandler.js';
import { uiHandler } from './uiHandler.js';
import { formatters } from './formatters.js';

// State Management
let messageHistory = [];
let currentLanguage = 'en';

// Core Initialization
function initializeChat() {
    if (messageHistory.length === 0) {
        addMessage('assistant', config.welcomeMessages[currentLanguage]);
    }
    updatePlaceholder();
    displayConversation();
}

let isInitialized = false;
document.addEventListener('DOMContentLoaded', () => {
    if (isInitialized) return;
    isInitialized = true;

    initializeChat();
    setupEventListeners();

    const container = document.getElementById('fileActionsRoot');
    if (container) {
        uiHandler.createFileActionsDropdown(container, currentLanguage);
    }
}, { once: true });

// Event Listeners
function setupEventListeners() {
    const elements = {
        sendButton: document.getElementById("sendButton"),
        savePageButton: document.getElementById("savePageButton"),
        saveConversationButton: document.getElementById("saveConversationButton"),
        screenshotButton: document.getElementById("screenshotButton"),
        addFileButton: document.getElementById("addFileButton"),
        userInput: document.getElementById("userInput")
    };

    if (!validateElements(elements)) return;

    elements.sendButton.addEventListener("click", handleSendMessage);
    elements.savePageButton.addEventListener("click", handlePageAnalysis);
    elements.saveConversationButton.addEventListener("click", handleSaveConversation);
    elements.screenshotButton.addEventListener("click", handleScreenshot);
    elements.addFileButton.addEventListener("click", handleFileUpload);

    elements.userInput.addEventListener("keypress", (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            handleSendMessage();
        }
    });

    setupLanguageSelector();
}

function validateElements(elements) {
    for (const [key, element] of Object.entries(elements)) {
        if (!element) {
            console.error(`Required element not found: ${key}`);
            return false;
        }
    }
    return true;
}

function setupLanguageSelector() {
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.addEventListener('click', () => handleLanguageChange(btn));
    });
}

// Language Handling
function handleLanguageChange(btn) {
    document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentLanguage = btn.dataset.lang;

    updatePlaceholder();
    displayConversation();

    const container = document.getElementById('fileActionsRoot');
    if (container) {
        uiHandler.createFileActionsDropdown(container, currentLanguage);
    }
}

// UI Updates
function updatePlaceholder() {
    const userInput = document.getElementById("userInput");
    if (userInput) {
        userInput.placeholder = config.placeholders[currentLanguage];
    }
}

function displayConversation() {
    const responseDiv = document.getElementById("response");
    if (!responseDiv) return;

    try {
        const formattedMessages = messageHistory.map(msg => {
            const timeStr = new Date(msg.timestamp).toLocaleTimeString(
                currentLanguage === 'zh' ? 'zh-CN' :
                currentLanguage === 'ms' ? 'ms-MY' : 'en-US',
                { hour: '2-digit', minute: '2-digit' }
            );
            return formatMessage(msg, timeStr);
        }).join('');

        responseDiv.innerHTML = formattedMessages;
        responseDiv.scrollTop = responseDiv.scrollHeight;
    } catch (error) {
        console.error('Error displaying conversation:', error);
    }
}

// Message Handling
async function handleSendMessage() {
    const userInput = document.getElementById("userInput");
    const inputValue = userInput ? userInput.value.trim() : '';
    if (!inputValue) return;

    try {
        addMessage("user", inputValue);
        userInput.value = "";

        addMessage("assistant", "Thinking", { isThinking: true });

        const messages = await messageHandler.prepareMessages(messageHistory, currentLanguage);
        const response = await api.makeRequest(messages);

        messageHistory = messageHistory.filter(msg => !msg.isThinking);
        addMessage("assistant", response.choices[0].message.content);

    } catch (error) {
        handleError(error);
    }
}

async function handlePageAnalysis() {
    const userInput = document.getElementById("userInput").value.trim();
    if (!userInput) {
        addMessage("assistant", config.warningMessages[currentLanguage]);
        return;
    }

    try {
        document.getElementById("userInput").value = "";
        addMessage("assistant", config.betaWarnings[currentLanguage]);

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) throw new Error('No active tab found');

        const result = await api.getPageContent(tab.id);
        if (!result?.[0]?.result) throw new Error('Failed to capture page content');

        const pageData = result[0].result;
        const response = await messageHandler.handlePageAnalysis(userInput, pageData, currentLanguage);

        addMessage("user", `Analyzing Page (Focus: ${userInput})`);
        addMessage("assistant", response);

    } catch (error) {
        handleError(error);
    }
}

async function handleSaveConversation() {
    try {
        uiUtils.showLoading();
        const fileName = await fileHandler.saveConversation(messageHistory, currentLanguage);

        addMessage("system", config.successMessages.chatSaved[currentLanguage](fileName));
        uiUtils.hideLoading();
        uiUtils.showStatus(config.statusMessages.saved[currentLanguage]);

    } catch (error) {
        handleError(error);
    }
}

async function handleScreenshot() {
    const userInput = document.getElementById("userInput").value.trim();
    if (!userInput) {
        handleError(new Error(config.errorMessages.noScreenshotInput[currentLanguage]));
        return;
    }

    try {
        document.getElementById("userInput").value = "";
        addMessage("user", userInput);

        const result = await screenshotHandler.captureScreenshot(messageHistory, currentLanguage);
        addMessage("assistant", result.response);
        addMessage("system", config.successMessages.screenshot[currentLanguage](result.filename));

    } catch (error) {
        handleError(error);
    }
}

// File Handling
async function handleFileUpload() {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.txt';

    fileInput.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        try {
            if (file.name.split('.').pop().toLowerCase() !== 'txt') {
                addMessage("system", config.errorMessages.invalidFileType[currentLanguage]);
                return;
            }

            addMessage("system", config.loadingMessages.fileProcessing[currentLanguage],
                      { isThinking: true });

            const content = await readFileContent(file);

            messageHistory = messageHistory.filter(msg => !msg.isThinking);

            addMessage("system",
                      config.successMessages.fileAdded[currentLanguage](file.name),
                      { isFile: true, fileName: file.name, fileContent: content });

            addMessage("system",
                      config.successMessages.fileUploaded[currentLanguage](file.name));

        } catch (error) {
            console.error('File upload error:', error);
            handleError(error);
        }
    };

    fileInput.click();
}

async function readFileContent(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => resolve(event.target.result);
        reader.onerror = (error) => reject(error);
        reader.readAsText(file);
    });
}

// Message Formatting
function formatMessage(msg, timeStr) {
    const roleDisplay = {
        'user': {
            'en': 'You',
            'zh': '你',
            'ms': 'Anda'
        },
        'system': {
            'en': 'System',
            'zh': '系统',
            'ms': 'Sistem'
        },
        'assistant': {
            'en': 'Assistant',
            'zh': '助手',
            'ms': 'Pembantu'
        }
    }[msg.role]?.[currentLanguage] || msg.role;

    if (msg.isThinking) {
        const thinkingText = {
            'en': 'Thinking',
            'zh': '思考中',
            'ms': 'Berfikir'
        }[currentLanguage];

        return `
            <div class="message thinking">
                <div class="message-header">${roleDisplay} • ${timeStr}</div>
                <div class="message-content thinking-indicator">
                    <span>${thinkingText}</span>
                    <div class="dot-animation">
                        <div class="dot"></div>
                        <div class="dot"></div>
                        <div class="dot"></div>
                    </div>
                </div>
            </div>
        `;
    }

    if (msg.isFile) {
        const noContentText = {
            'en': 'No content available',
            'zh': '无可用内容',
            'ms': 'Tiada kandungan tersedia'
        }[currentLanguage];

        return `
            <div class="message file">
                <div class="message-header">${roleDisplay} • ${timeStr}</div>
                <div class="file-message">
                    <div class="file-header">
                        <svg class="file-icon" viewBox="0 0 24 24" fill="none" stroke="#34a853" stroke-width="2">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                            <path d="M14 2v6h6"/>
                            <path d="M16 13H8"/>
                            <path d="M16 17H8"/>
                            <path d="M10 9H8"/>
                        </svg>
                        <span class="file-title">${msg.fileName}</span>
                    </div>
                    <div class="file-content" style="white-space: pre-wrap;">
                        ${msg.fileContent ? msg.fileContent.substring(0, 1000) +
                          (msg.fileContent.length > 1000 ? '...' : '') : noContentText}
                    </div>
                </div>
            </div>
        `;
    }

    if (msg.role === 'system' && msg.content.includes('Chat saved')) {
        return `
            <div class="message system">
                <div class="message-header">${roleDisplay} • ${timeStr}</div>
                <div class="message-content save-success">
                    ${msg.content.replace(/\n/g, '<br>')}
                </div>
            </div>
        `;
    }

    if (msg.role === 'assistant' && msg.content.includes('beta')) {
        return `
            <div class="message ${msg.role}">
                <div class="message-header">${roleDisplay} • ${timeStr}</div>
                <div class="message-content beta-warning">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                    </svg>
                    ${msg.content}
                </div>
            </div>
        `;
    }

    let content = msg.content;
    if (msg.role === 'assistant') {
        content = content
            .replace(/--- ###/g, '<br><br><strong>Section</strong>')
            .replace(/\. -/g, '.<br>')
            .replace(/(\d+\.) /g, '<br><br>$1 ')
            .replace(/\*\*(.*?)\*\*/g, '<span class="highlight">$1</span>')
            .replace(/- \*\*(.*?)\*\*/g, '<br>• <strong>$1</strong>');
    }

    return `
        <div class="message ${msg.role}">
            <div class="message-header">${roleDisplay} • ${timeStr}</div>
            <div class="message-content">${content}</div>
        </div>
    `;
}

// Helper Functions
function addMessage(role, content, options = {}) {
    const message = {
        role,
        content,
        timestamp: new Date().toISOString(),
        ...options
    };

    messageHistory.push(message);
    displayConversation();
}

function handleError(error) {
    console.error('Error:', error);
    uiUtils.hideLoading();
    addMessage("assistant", formatters.formatErrorMessage(error, currentLanguage));
}

function setupDialogEvents() {
    const dialog = document.getElementById('aboutDialog');
    const aboutBtn = document.getElementById('aboutButton');
    const closeBtn = document.getElementById('closeDialog');
    const cancelBtn = document.getElementById('cancelBtn');
    const continueBtn = document.getElementById('continueBtn');

    if (!dialog || !aboutBtn || !closeBtn || !cancelBtn || !continueBtn) {
        console.error('Some dialog elements are missing');
        return;
    }

    // Show dialog
    aboutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        dialog.classList.remove('hidden');
    });

    // Hide dialog
    const hideDialog = () => dialog.classList.add('hidden');

    closeBtn.addEventListener('click', hideDialog);
    cancelBtn.addEventListener('click', hideDialog);

    continueBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'https://asean-ai.com/operator_x01/' });
        hideDialog();
    });

    // Close on outside click
    dialog.addEventListener('click', (e) => {
        if (e.target === dialog) hideDialog();
    });

    // Close on escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !dialog.classList.contains('hidden')) {
            hideDialog();
        }
    });
}

// Add to DOMContentLoaded event
document.addEventListener('DOMContentLoaded', () => {
    if (isInitialized) return;
    isInitialized = true;

    initializeChat();
    setupEventListeners();
    setupDialogEvents();  // Make sure this is called

    const container = document.getElementById('fileActionsRoot');
    if (container) {
        uiHandler.createFileActionsDropdown(container, currentLanguage);
    }
}, { once: true });
export { messageHistory, currentLanguage };