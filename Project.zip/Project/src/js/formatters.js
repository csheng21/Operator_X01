export const formatters = {
    formatTimestamp(timestamp, currentLanguage) {
        return new Date(timestamp).toLocaleTimeString(
            currentLanguage === 'zh' ? 'zh-CN' :
            currentLanguage === 'ms' ? 'ms-MY' : 'en-US',
            { hour: '2-digit', minute: '2-digit' }
        );
    },

    formatFileContent(content, maxLength = 1000, currentLanguage) {
        if (!content) {
            return {
                'en': 'No content available',
                'zh': '无可用内容',
                'ms': 'Tiada kandungan tersedia'
            }[currentLanguage];
        }

        return content.length > maxLength ?
            `${content.substring(0, maxLength)}...` :
            content;
    },

    formatErrorMessage(error, currentLanguage) {
        return {
            'en': `Error: ${error.message}`,
            'zh': `错误：${error.message}`,
            'ms': `Ralat: ${error.message}`
        }[currentLanguage];
    }
};