const path = require('path');
const CopyPlugin = require('copy-webpack-plugin');
const Dotenv = require('dotenv-webpack');

module.exports = {
    entry: {
        sidepanel: './src/js/sidepanel.js',
        'service-worker': './src/service-worker.js',
        selection: './src/js/selection.js'  // Add this entry point
    },
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: '[name].js',
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env']
                    }
                }
            }
        ]
    },
    plugins: [
        new CopyPlugin({
            patterns: [
                { from: "src/*.html", to: "[name][ext]" },
                { from: "src/css", to: "css" },
                { from: "src/icons", to: "icons" },
                { from: "src/manifest.json", to: "manifest.json" },
                { from: "src/css/selection.css", to: "selection.css" }  // Add this line
            ],
        }),
        new Dotenv()
    ],
    resolve: {
        extensions: ['.js', '.json']
    }
};