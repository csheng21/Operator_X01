export const uiUtils = {
    showLoading(responseDiv, currentLanguage) {
        const loadingDiv = document.createElement('div');
        loadingDiv.id = 'loadingIndicator';
        loadingDiv.className = 'thinking-indicator';

        loadingDiv.innerHTML = `
            <span>${this.getThinkingText(currentLanguage)}</span>
            <div class="dot-animation">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
        `;

        responseDiv.appendChild(loadingDiv);
        responseDiv.scrollTop = responseDiv.scrollHeight;
    },

    hideLoading() {
        const loadingIndicator = document.getElementById('loadingIndicator');
        if (loadingIndicator) loadingIndicator.remove();
    },

    formatTimestamp(date, currentLanguage) {
        switch(currentLanguage) {
            case 'zh':
                return `${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`;
            case 'ms':
                return date.toLocaleTimeString('ms-MY', {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                });
            default:
                return date.toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                });
        }
    },

    showStatus(message, duration = 3000) {
        const statusDiv = document.getElementById('saveStatus');
        statusDiv.textContent = message;
        statusDiv.style.opacity = '1';
        setTimeout(() => {
            statusDiv.style.opacity = '0';
            setTimeout(() => {
                statusDiv.textContent = '';
            }, 300);
        }, duration);
    },

    getThinkingText(currentLanguage) {
        return {
            'en': 'Thinking',
            'zh': '思考中',
            'ms': 'Memproses'
        }[currentLanguage] || 'Thinking';
    }
};