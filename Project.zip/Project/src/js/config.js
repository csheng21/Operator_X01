export const config = {
    systemPrompts: {
        'en': 'You are a helpful assistant. You must respond only in English.',
        'zh': '您是一位专业的助手。您必须只使用中文回答。',
        'ms': 'Anda adalah pembantu yang profesional. Anda mesti menjawab dalam Bahasa Melayu sahaja.'
    },

    welcomeMessages: {
        'en': 'Hello! How can I assist you today?',
        'zh': '你好！我能为您做些什么？',
        'ms': 'Hai! Apa yang boleh saya bantu hari ini?'
    },

    placeholders: {
        'en': 'Enter message or what to analyze...',
        'zh': '输入消息或要分析的内容...',
        'ms': 'Masukkan mesej atau apa yang hendak dianalisis...'
    },

    betaWarnings: {
        'en': 'Note: Page analysis feature is in beta. Some functionality may be limited.',
        'zh': '注意：网页分析功能仍在测试阶段，部分功能可能不够完善。',
        'ms': 'Nota: Ciri analisis laman masih dalam versi beta. Sesetengah fungsi mungkin terhad.'
    },

    thinkingText: {
        'en': 'Thinking',
        'zh': '思考中',
        'ms': 'Memproses'
    }
};