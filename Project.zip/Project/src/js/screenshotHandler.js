import { api } from './api.js';
import { config } from './config.js';

export const screenshotHandler = {
    async captureScreenshot(messageHistory, currentLanguage) {
        try {
            const userInput = document.getElementById("userInput").value.trim();
            if (!userInput) {
                throw new Error({
                    'en': 'Please enter what you want to know about this page.',
                    'zh': '请输入您想了解此页面的内容。',
                    'ms': 'Sila masukkan apa yang anda ingin tahu tentang halaman ini.'
                }[currentLanguage]);
            }

            // Add thinking message
            const thinkingMsg = {
                role: "assistant",
                content: "Thinking",
                isThinking: true,
                timestamp: new Date().toISOString()
            };
            messageHistory.push(thinkingMsg);

            // Capture screenshot
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });

            // Get page content
            const result = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                function: () => document.body.innerText
            });

            const pageContent = result[0].result;

            // Get AI response
            const messages = [
                {
                    role: "system",
                    content: config.systemPrompts[currentLanguage]
                },
                {
                    role: "system",
                    content: `You must respond only in ${
                        currentLanguage === 'en' ? 'English' :
                        currentLanguage === 'zh' ? 'Chinese (中文)' :
                        'Bahasa Melayu'
                    }.`
                },
                {
                    role: "user",
                    content: `Based on this webpage content: "${pageContent}"\n\nUser question: ${userInput}`
                }
            ];

            const response = await api.makeRequest(messages);

            // Save screenshot
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const filename = `screenshot_${timestamp}.png`;

            await chrome.downloads.download({
                url: dataUrl,
                filename: filename,
                saveAs: false
            });

            return {
                response: response.choices[0].message.content,
                filename
            };

        } catch (error) {
            throw error;
        }
    },

    async handleSelectionScreenshot(message, messageHistory) {
        try {
            await new Promise(resolve => setTimeout(resolve, 100));
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });

            const img = new Image();
            img.src = dataUrl;
            await new Promise(resolve => { img.onload = resolve; });

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = message.rect.width;
            canvas.height = message.rect.height;

            ctx.drawImage(img,
                message.rect.left, message.rect.top,
                message.rect.width, message.rect.height,
                0, 0,
                message.rect.width, message.rect.height
            );

            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const filename = `selection_screenshot_${timestamp}.png`;
            const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
            const url = URL.createObjectURL(blob);

            await chrome.downloads.download({
                url: url,
                filename: filename,
                saveAs: false
            });

            URL.revokeObjectURL(url);
            return filename;

        } catch (error) {
            throw error;
        }
    }
};