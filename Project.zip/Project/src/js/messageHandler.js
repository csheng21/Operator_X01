import { api } from './api.js';
import { config } from './config.js';

export const messageHandler = {
    async handleMessageSend(userInput, messageHistory, currentLanguage) {
        if (!userInput) return;

        try {
            messageHistory.push({
                role: "user",
                content: userInput,
                timestamp: new Date().toISOString()
            });

            // Show thinking state
            const thinkingMsg = {
                role: "assistant",
                content: "Thinking",
                isThinking: true,
                timestamp: new Date().toISOString()
            };
            messageHistory.push(thinkingMsg);

            // Get response
            const messages = await this.prepareMessages(messageHistory, currentLanguage);
            const response = await api.makeRequest(messages);

            // Remove thinking message
            messageHistory = messageHistory.filter(msg => !msg.isThinking);

            // Add assistant response
            messageHistory.push({
                role: "assistant",
                content: response.choices[0].message.content,
                timestamp: new Date().toISOString()
            });

        } catch (error) {
            this.handleError(error, messageHistory, currentLanguage);
        }
    },

    async handleFileMessages(userInput, fileReferences) {
        let fileContents = [];
        if (userInput.toLowerCase().includes('file') ||
            fileReferences.some(file => userInput.toLowerCase().includes(file.fileName.toLowerCase()))) {
            fileContents = fileReferences.map(file => ({
                role: "system",
                content: `File: ${file.fileName}\nContent:\n${file.fileContent}`
            }));
        }
        return fileContents;
    },

    async prepareMessages(messageHistory, currentLanguage) {
        const systemPrompts = [
            {
                role: "system",
                content: config.systemPrompts[currentLanguage]
            },
            {
                role: "system",
                content: `You must respond only in ${
                    currentLanguage === 'en' ? 'English' :
                    currentLanguage === 'zh' ? 'Chinese (中文)' :
                    'Bahasa Melayu'
                }.`
            }
        ];

        const conversationHistory = messageHistory
            .filter(msg => msg.role !== "system" && !msg.isThinking)
            .map(msg => ({
                role: msg.role,
                content: msg.content
            }));

        return [...systemPrompts, ...conversationHistory];
    },

    handleError(error, messageHistory, currentLanguage) {
        console.error('Error:', error);
        const errorMessage = {
            'en': `Error: ${error.message}`,
            'zh': `错误：${error.message}`,
            'ms': `Ralat: ${error.message}`
        }[currentLanguage];

        messageHistory.push({
            role: "system",
            content: errorMessage,
            timestamp: new Date().toISOString()
        });
    },

    getWelcomeMessage(currentLanguage) {
        return {
            role: 'assistant',
            content: config.welcomeMessages[currentLanguage],
            timestamp: new Date().toISOString()
        };
    },

    getThinkingMessage() {
        return {
            role: "assistant",
            content: "Thinking",
            isThinking: true,
            timestamp: new Date().toISOString()
        };
    },

    formatResponse(response, currentLanguage) {
        return {
            role: "assistant",
            content: response.choices[0].message.content,
            timestamp: new Date().toISOString()
        };
    }
};