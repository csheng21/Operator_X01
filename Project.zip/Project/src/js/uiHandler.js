export const uiHandler = {
    createFileActionsDropdown(container, currentLanguage) {
        if (!container) return;

        container.innerHTML = '';
        const translations = {
            addFile: {
                'en': 'Add File',
                'zh': '添加文件',
                'ms': 'Tambah Fail'
            },
            saveChat: {
                'en': 'Save Chat',
                'zh': '保存聊天',
                'ms': 'Simpan Perbualan'
            }
        };

        const dropdownHTML = `
            <div class="file-actions-dropdown">
                <button class="file-actions-btn" title="${translations.addFile[currentLanguage]}">
                    <svg width="24" height="24" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" fill="none">
                        <path d="M19 9l-7 7-7-7"/>
                    </svg>
                </button>
                <div class="dropdown-menu hidden">
                    <button class="dropdown-item" data-action="addFile">
                        <svg class="menu-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 5v14M5 12h14"/>
                            <rect x="3" y="3" width="18" height="18" rx="2"/>
                        </svg>
                        <span>${translations.addFile[currentLanguage]}</span>
                    </button>
                    <button class="dropdown-item" data-action="saveChat">
                        <svg class="menu-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                            <path d="M17 21v-8H7v8"/>
                        </svg>
                        <span>${translations.saveChat[currentLanguage]}</span>
                    </button>
                </div>
            </div>
        `;

        container.innerHTML = dropdownHTML;

        const dropdown = container.querySelector('.file-actions-dropdown');
        const toggleBtn = container.querySelector('.file-actions-btn');
        const menu = container.querySelector('.dropdown-menu');

        if (!dropdown || !toggleBtn || !menu) return;

        const handleOutsideClick = (e) => {
            if (!dropdown.contains(e.target)) {
                menu.classList.add('hidden');
            }
        };

        document.removeEventListener('click', handleOutsideClick);

        toggleBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            menu.classList.toggle('hidden');
        });

        container.querySelectorAll('.dropdown-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.stopPropagation();
                const action = item.dataset.action;

                if (action === 'addFile') {
                    const addFileBtn = document.getElementById('addFileButton');
                    if (addFileBtn) addFileBtn.click();
                } else if (action === 'saveChat') {
                    const saveChatBtn = document.getElementById('saveConversationButton');
                    if (saveChatBtn) saveChatBtn.click();
                }

                menu.classList.add('hidden');
            });
        });

        document.addEventListener('click', handleOutsideClick);
    },

    setupDialogEvents() {
        const dialog = document.getElementById('aboutDialog');
        const aboutBtn = document.getElementById('aboutButton');
        const closeBtn = document.getElementById('closeDialog');
        const cancelBtn = document.getElementById('cancelBtn');
        const continueBtn = document.getElementById('continueBtn');

        if (!dialog || !aboutBtn || !closeBtn || !cancelBtn || !continueBtn) {
            console.error('Some dialog elements are missing');
            return;
        }

        aboutBtn.replaceWith(aboutBtn.cloneNode(true));
        closeBtn.replaceWith(closeBtn.cloneNode(true));
        cancelBtn.replaceWith(cancelBtn.cloneNode(true));
        continueBtn.replaceWith(continueBtn.cloneNode(true));

        document.getElementById('aboutButton').addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dialog.classList.remove('hidden');
        });

        document.getElementById('closeDialog').addEventListener('click', this.hideDialog);
        document.getElementById('cancelBtn').addEventListener('click', this.hideDialog);
        document.getElementById('continueBtn').addEventListener('click', () => {
            chrome.tabs.create({ url: 'https://asean-ai.com/operator_x01/' });
            this.hideDialog();
        });

        dialog.addEventListener('click', (e) => {
            if (e.target === dialog) this.hideDialog();
        });
    },

    hideDialog() {
        const dialog = document.getElementById('aboutDialog');
        if (dialog) {
            dialog.classList.add('hidden');
        }
    }
};