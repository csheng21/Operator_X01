// Listen for installation
chrome.runtime.onInstalled.addListener(() => {
  // Initialize side panel
  if (chrome.sidePanel) {
    chrome.sidePanel.setOptions({
      enabled: true,
      path: 'sidepanel.html'
    });
  }
});

// Listen for action button click
chrome.action.onClicked.addListener((tab) => {
  // Open side panel when extension icon is clicked
  if (chrome.sidePanel) {
    chrome.sidePanel.open({ windowId: tab.windowId });
  }
});

// Keep service worker active
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Handle any messages from the side panel
  if (message.type === 'KEEP_ALIVE') {
    sendResponse({ status: 'alive' });
  }
  return true;
});

// Handle side panel state
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'sidepanel') {
    port.onDisconnect.addListener(() => {
      // Clean up when side panel is closed
      console.log('Side panel disconnected');
    });
  }
});

// Error handling
chrome.runtime.onError.addListener((error) => {
  console.error('Extension error:', error.message);
});