import { api } from './api.js';

export const fileHandler = {
    async handleFileUpload(messageHistory, currentLanguage) {
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.txt';

        fileInput.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            try {
                if (file.name.split('.').pop().toLowerCase() !== 'txt') {
                    throw new Error(this.getErrorMessage('invalidFile', currentLanguage));
                }

                // Add loading message
                messageHistory.push(this.getLoadingMessage(currentLanguage));

                const content = await this.readFileContent(file);

                // Remove loading message
                messageHistory = messageHistory.filter(msg => !msg.isThinking);

                // Add file messages
                messageHistory.push(
                    this.getFileAddedMessage(file.name, content, currentLanguage),
                    this.getSuccessMessage(file.name, currentLanguage)
                );

            } catch (error) {
                console.error('File upload error:', error);
                messageHistory.push(this.getErrorMessage(error.message, currentLanguage));
            }
        };

        fileInput.click();
    },

    async readFileContent(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (event) => resolve(event.target.result);
            reader.onerror = (error) => reject(error);
            reader.readAsText(file);
        });
    },

    async saveConversation(messageHistory, currentLanguage) {
        try {
            const summary = await this.createSummary(messageHistory, currentLanguage);
            const fileName = await this.generateFile(messageHistory, summary, currentLanguage);
            return fileName;
        } catch (error) {
            throw error;
        }
    },

    async createSummary(messages, currentLanguage) {
        const summaryPrompt = this.getSummaryPrompt(currentLanguage);
        const conversationText = this.prepareConversationText(messages);

        const response = await api.makeRequest([
            this.getLanguagePrompt(currentLanguage),
            {
                role: "user",
                content: `${summaryPrompt}\n\nConversation:\n${conversationText}`
            }
        ]);

        return response.choices[0].message.content;
    },

    async generateFile(messageHistory, summary, currentLanguage) {
        const now = new Date();
        const formattedDateTime = this.formatDateTime(now);
        const headers = this.getHeaders(now, currentLanguage);
        const sectionHeaders = this.getSectionHeaders(currentLanguage);
        const conversationHistory = this.formatConversationHistory(messageHistory);

        const fullText = `${headers}${sectionHeaders.summary}${summary}${sectionHeaders.history}${conversationHistory}`;
        const fileName = `Operator_X01_Chat_${formattedDateTime}.txt`;

        await this.downloadFile(fileName, fullText);
        return fileName;
    },

    async downloadFile(fileName, content) {
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);

        await chrome.downloads.download({
            url: url,
            filename: fileName,
            saveAs: false
        });

        URL.revokeObjectURL(url);
    },

    getSummaryPrompt(currentLanguage) {
        return {
            'en': `Please analyze this conversation and provide a structured summary with the following sections:
                  **Introduction**
                  **Key Points**
                  **Main Topics Discussed**
                  **Key Decisions**
                  **Conclusion**`,
            'zh': `请分析此对话并提供包含以下部分的结构化摘要：
                  **简介**
                  **要点**
                  **主要讨论的话题**
                  **关键决定**
                  **结论**`,
            'ms': `Sila analisis perbualan ini dan berikan ringkasan berstruktur dengan bahagian berikut:
                  **Pengenalan**
                  **Perkara Utama**
                  **Topik Utama yang Dibincangkan**
                  **Keputusan Utama**
                  **Kesimpulan**`
        }[currentLanguage];
    },

    getLanguagePrompt(currentLanguage) {
        return {
            role: "system",
            content: `You must respond only in ${
                currentLanguage === 'en' ? 'English' :
                currentLanguage === 'zh' ? 'Chinese (中文)' :
                'Bahasa Melayu'
            }.`
        };
    },

    prepareConversationText(messages) {
        return messages
            .filter(msg => msg.role !== "system")
            .map(msg => `${msg.role}: ${msg.content}`)
            .join('\n');
    },

    formatDateTime(date) {
        return date.toISOString()
            .replace(/[:.]/g, '')
            .replace('T', '_')
            .split('.')[0]
            .replace('Z', '');
    },

    getHeaders(date, currentLanguage) {
        const headers = {
            'en': 'OPERATOR_X01 CHAT SUMMARY',
            'zh': 'OPERATOR_X01 对话总结',
            'ms': 'RINGKASAN PERBUALAN OPERATOR_X01'
        };

        return `===============================
${headers[currentLanguage]}
===============================
Date: ${date.toISOString().split('T')[0]}
Time: ${date.toLocaleTimeString()}
Generated by: Operator_X01
Version: 1.0
===============================\n\n`;
    },

    getSectionHeaders(currentLanguage) {
        return {
            'en': {
                summary: '=== CONVERSATION SUMMARY ===\n\n',
                history: '\n\n=== FULL CONVERSATION HISTORY ===\n\n'
            },
            'zh': {
                summary: '=== 对话总结 ===\n\n',
                history: '\n\n=== 完整对话历史 ===\n\n'
            },
            'ms': {
                summary: '=== RINGKASAN PERBUALAN ===\n\n',
                history: '\n\n=== SEJARAH PERBUALAN LENGKAP ===\n\n'
            }
        }[currentLanguage];
    },

    formatConversationHistory(messageHistory) {
        return messageHistory
            .filter(msg => msg.role !== "system")
            .map(msg => {
                const date = new Date(msg.timestamp);
                const timeStr = date.toLocaleString();
                const role = msg.role === 'user' ? 'You' : 'Assistant';
                return `[${timeStr}] ${role}:\n${msg.content}\n`;
            })
            .join('\n---\n\n');
    },

    getLoadingMessage(currentLanguage) {
        return {
            role: "system",
            content: {
                'en': 'Processing file...',
                'zh': '正在处理文件...',
                'ms': 'Memproses fail...'
            }[currentLanguage],
            isThinking: true,
            timestamp: new Date().toISOString()
        };
    },

    getFileAddedMessage(fileName, content, currentLanguage) {
        return {
            role: "system",
            content: `📎 ${
                currentLanguage === 'en' ? 'Added file' :
                currentLanguage === 'zh' ? '已添加文件' :
                'Fail ditambah'
            }: ${fileName}`,
            isFile: true,
            fileName: fileName,
            fileContent: content,
            timestamp: new Date().toISOString()
        };
    },

    getSuccessMessage(fileName, currentLanguage) {
        return {
            role: "system",
            content: `✅ ${
                currentLanguage === 'en' ? 'File added successfully' :
                currentLanguage === 'zh' ? '文件添加成功' :
                'Fail berjaya ditambah'
            }: ${fileName}`,
            timestamp: new Date().toISOString()
        };
    },

    getErrorMessage(error, currentLanguage) {
        return {
            role: "system",
            content: {
                'invalidFile': {
                    'en': '❌ Only .txt files are supported. Please upload a text file.',
                    'zh': '❌ 仅支持.txt文件。请上传文本文件。',
                    'ms': '❌ Hanya fail .txt disokong. Sila muat naik fail teks.'
                }
            }[error]?.[currentLanguage] || String(error),
            timestamp: new Date().toISOString()
        };
    }
};