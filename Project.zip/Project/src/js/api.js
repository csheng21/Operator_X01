export const api = {
    baseUrl: 'https://api.deepseek.com/v1/chat/completions',
    apiKey: '/*API_KEY*/"',

    async makeRequest(messages, maxTokens = 2000) {
        const response = await fetch(this.baseUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.apiKey}`
            },
            body: JSON.stringify({
                model: "/*Model_Name*/",
                messages,
                max_tokens: maxTokens,
                temperature: 0.7
            })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error?.message || 'API request failed');
        }
        return response.json();
    },

    async getPageContent(tabId) {
        return chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
                const cleanText = (text) => {
                    return text
                        .replace(/[\u0000-\u001F\u007F-\u009F]/g, '')
                        .replace(/\s+/g, ' ')
                        .trim();
                };

                return {
                    title: cleanText(document.title).substring(0, 200),
                    content: cleanText(document.body.innerText).substring(0, 6000),
                    url: window.location.href
                };
            }
        });
    }
};